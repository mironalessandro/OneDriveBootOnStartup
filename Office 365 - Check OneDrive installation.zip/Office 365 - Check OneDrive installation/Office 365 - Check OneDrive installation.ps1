﻿$onedrive_exists = "true"
try
{
    $exreg = Get-ItemProperty -Path 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run\' -Name OneDrive -ErrorAction Stop
}
catch
{
    $onedrive_exists = "false"
}

if ($onedrive_exists -eq "false")
{
    $Folder_x86 = 'C:\Program Files (x86)\Microsoft OneDrive'
    $Folder_x64 = 'C:\Program Files\Microsoft OneDrive'
    if (Test-Path -Path $Folder_x64) 
    {
        New-ItemProperty -Path HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run\ -Name OneDrive -Value '"C:\Program Files\Microsoft OneDrive\OneDrive.exe" /background' 
    } 
    if (Test-Path -Path $Folder_x86) 
    {
        New-ItemProperty -Path HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run\ -Name OneDrive -Value '"C:\Program Files (x86)\Microsoft OneDrive\OneDrive.exe" /background' 
    }

}
